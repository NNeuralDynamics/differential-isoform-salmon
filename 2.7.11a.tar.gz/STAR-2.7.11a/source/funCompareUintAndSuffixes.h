#ifndef CODE_funCompareUintAndSuffixes
#define CODE_funCompareUintAndSuffixes

#include <stdint.h>

extern char* g_funCompareUintAndSuffixes_G;
extern uint64_t g_funCompareUintAndSuffixes_L;

int funCompareUintAndSuffixes ( const void *a, const void *b);

#endif
