#include "ReadAlign.h"

void ReadAlign::outputVariation(Variation &Var, Transcript Tr, uint iTr, uint nTr)
{
    if (!Var.yes)
    {
        return;
    };




};
